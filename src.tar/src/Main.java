import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.SQLOutput;
import java.util.*;

import static java.lang.Thread.sleep;

public class Main {

    public static void main(String[] args) {
        String filename;
        int[] currCoords;

        // coordinates of the destination node in array format [x,y]
        int[] destCoords;

        // Contains all obstacles in string format
        PriorityQueue<String> obstacles;

        if(args.length > 0) {
            // pull filename from command line args
            filename = args[0];
            //initialize empty map
            ArrayList<String[]> map;

            //temporary new route object
            Route newPath;

            // Create new MapReader object
            MapReader reader = new MapReader(filename);
            // Get the start coordinates from the MapReader
            currCoords = reader.getInitCoords();
            // Get the destination coordinates from the MapReader
            destCoords = reader.getDestinationCoords();
            // Get the coordinates of all obstacles from the MapReader
            obstacles = reader.getObstacles();

            // Create the start node using the currCoords initial value
            Node startNode = new Node(currCoords[0],currCoords[1],destCoords[0],destCoords[1],0, obstacles);

            System.out.println(""+startNode.manDistance);
            // Create a new Route with the startNode as the only element

            Route path = new Route(startNode);

            // Create a queue to store all visited coordinates


            // Create an array of Routes to store different paths
            ArrayList<Route> routes = new ArrayList<Route>();

            // Store the first path
            routes.add(path);

            // Add the coordinates of the startNode to the visitedCoords
            routes.get(0).addVisited(startNode);

            // ACTUAL ALGORITHM
            System.out.println(currCoords[0] + "," + currCoords[1]);
            System.out.println(destCoords[0] + "," + destCoords[1]);
            int mapDim = reader.getMap().size();

            Route successRoute = new Route();

            Boolean done = false;


            while(!currCoords.equals(destCoords)) {
                // Intialize an empy array of Nodes to explore the fringe
                //ArrayList<Node> edgeNodes = new ArrayList<>();

                //for each path in routes, peak on the path (take first val), and insert resunt into edge edgeNodes

                ArrayList<Route> newRoutes = new ArrayList<>();

                // iterate through all current routes
                for(Route r : routes){
                    //create a new node to contain the headnode data
                    Node headNode = r.path.get(r.path.size() - 1);
                    int curr_x = headNode.node_x;
                    int curr_y = headNode.node_y;

                    currCoords[0] = curr_x;
                    currCoords[1] = curr_y;

                    //check if the headnode is the destination
                    if(Arrays.equals(currCoords,destCoords)){
                        r.hasArrived = true;
                    }

                    // if it is, break the for loop and set a boolean that will break the while loop
                    if(r.hasArrived){
                        successRoute = r;
                        done = true;
                        break;
                    }

                    //if the route has not hit a dead end and has not arrived, explore the fringe
                    if(!r.isLeaf && !r.hasArrived) {
                        // create new arraylist to hold the fringe nodes
                        ArrayList<Node> choices = new ArrayList<>(); // but how are we treating the obstacles


                        // printing variables for terminal
                        String up_print = "";
                        String down_print = "";
                        String right_print = "";
                        String left_print = "";
                        ////

                        //up
                        Node up = new Node(curr_x, curr_y - 1, destCoords[0], destCoords[1], headNode.cost + 1, obstacles);
                        if ((!up.isObstacle) && (curr_y - 1 >= 0) && (curr_x < mapDim) && (curr_y - 1 < mapDim) && (!r.visitedNodes.contains("" + up.node_x + "," + up.node_y))) {
                            choices.add(up);
                        }

                        //down
                        Node down = new Node(curr_x, curr_y + 1, destCoords[0], destCoords[1], headNode.cost + 1, obstacles);
                        if ((!down.isObstacle) && (curr_y + 1 >= 0) && (curr_x < mapDim) && (curr_y + 1 < mapDim) && (!r.visitedNodes.contains("" + down.node_x + "," + down.node_y))) {
                            choices.add(down);
                        }

                        //right
                        Node right = new Node(curr_x + 1, curr_y, destCoords[0], destCoords[1], headNode.cost + 1, obstacles);
                        if ((!right.isObstacle) && (curr_x + 1 >= 0) && (curr_x + 1 < mapDim) && (curr_y < mapDim) && (curr_x < mapDim) && (curr_y - 1 < mapDim) && (!r.visitedNodes.contains("" + right.node_x + "," + right.node_y))) {
                            choices.add(right);
                        }

                        //left
                        Node left = new Node(curr_x - 1, curr_y, destCoords[0], destCoords[1], headNode.cost + 1, obstacles);
                        if ((!left.isObstacle) && (curr_x - 1 >= 0) && (curr_x - 1 < mapDim) && (curr_y < mapDim) && (!r.visitedNodes.contains("" + left.node_x + "," + left.node_y))) {
                            choices.add(left);
                        }

                        // iterate through the choice nodes
                        for (int i =0;i < choices.size()-1;i++) {
                            Node choice_node = choices.get(i);

                            //create a new route that will hold all of the previous nodes in the path and add the choice node to the front
                            Route tempPath = new Route();

                            // add all previous nodes into new path
                            for (Node n : r.path) {
                                tempPath.addNode(n);
                            }
                            // add all visited coords to the new path
                            for (String coords : r.visitedNodes) {
                                tempPath.addVisitedString(coords);
                            }

                            // add the choice node and new coordinates to the new path
                            tempPath.addVisited(choice_node);
                            tempPath.addNode(choice_node);


                            newRoutes.add(tempPath);
                        }
                        if (choices.size() > 0) {
                            r.path.add(choices.get(choices.size() - 1));
                            r.addVisited(choices.get(choices.size() - 1));
                        } else {
                            // path terminated - leaf path
                            r.isLeaf = true;
                        }

                        if (up.isObstacle) {
                            up_print = " + ";
                        } else {
                            up_print = Integer.toString(up.totalCost);
                        }


                        if (down.isObstacle) {
                            down_print = " + ";
                        } else {
                            down_print = Integer.toString(down.totalCost);
                        }


                        if (right.isObstacle) {
                            right_print = " + ";
                        } else {
                            right_print = Integer.toString(right.totalCost);
                        }


                        if (left.isObstacle) {
                            left_print = " + ";
                        } else {
                            left_print = Integer.toString(left.totalCost);
                        }

//                        System.out.println("**************************");
//                        System.out.println("COST: " + headNode.totalCost);
//                        System.out.println("STEP: " + headNode.cost);
//                        System.out.println("[" + headNode.node_x + ", " + headNode.node_y + "]");
//                        System.out.println("\n  " + up_print + "  " + "\n" + left_print + " O " + right_print + "\n  " + down_print + "  ");

    //                        if(Integer.toString(headNode.node_x)+","+Integer.toString()
                        //                    System.out.println(best_node.totalCost);


//                        try {
//                            Thread.sleep(100);
//                        } catch (InterruptedException e) {
//                            e.printStackTrace();
//                        }
                    }

                    // re assign values
                    //curr_x = best_node.node_x;
                    //curr_y = best_node.node_y;

//                    currCoords[0] = best_node.node_x;
//                    currCoords[1] = best_node.node_y;

//                    r.path.add(best_node);
//                    r.visitedNodes.add(""+best_node.node_x+","+best_node.node_y);
                }

                for(Route tempR : newRoutes){
                    routes.add(tempR);
                }

                if(done) {break;}

            }

            System.out.println("Route Found");
            System.out.println(""+successRoute.getDistanceTraveled()+" steps taken");
            ArrayList<ArrayList<String>> outputMap = reader.getMap();
            for(Node n : successRoute.path){

                System.out.println("\n"+n.node_x+","+n.node_y);

                outputMap.get(n.node_y).set(n.node_x,"o");
            }

            for(ArrayList<String> row : outputMap){
                StringBuilder sb = new StringBuilder();
                for(String c : row){
                    sb.append(c);
                }
                System.out.println(sb.toString());
            }

            System.exit(0);



        }
        else {
            System.out.println("No filename provided. Quitting...");
            System.exit(1);
        }


    }
}
