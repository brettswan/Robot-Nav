import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;

public class Route {
//    Stack<Node> path = new Stack<>();
    ArrayList<Node> path;
    ArrayList<String> visitedNodes = new ArrayList<String>();
    Boolean isLeaf;
    Boolean hasArrived;

    public Route(Node n) {
        this.path = new ArrayList<>();
        this.path.add(n);
        this.isLeaf = false;
        this.hasArrived = false;
    }

    public Route() {
        this.path = new ArrayList<>();
        this.isLeaf = false;
        this.hasArrived = false;
    }

    public void addNode(Node n) {
        this.path.add(n);
    }

    public int getDistanceTraveled() {
        return this.path.size();
    }

    public void addVisited(Node n) {
        this.visitedNodes.add(""+n.node_x+","+n.node_y);
    }

    public void addVisitedString(String coords){
        this.visitedNodes.add(coords);
    }

    public void setLeaf() {
        this.isLeaf = true;
    }

}
